﻿namespace AdvancedBusinessDev.Repositories
{
    public interface IClienteRepository
    {
    }
}
